<?php
$servername = "localhost";
$username = "khadimul_madinah";
$password = "M)WogQc(#3]9";
$dbname = "khadimul_madinah";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    echo "failed ....";
  die("Connection failed: " . $conn->connect_error);
}
?>
