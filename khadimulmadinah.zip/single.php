<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <title>KHADIM UL MADINAH</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="TOUR AND TRAVEL" name="keywords">
    <meta content="Tour and Travel" name="description">

    <!-- Favicon -->
    <link href="img/logo favicon.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body onload="setActivePage('single-link')">
<?php 
     include_once 'connection.php';
     include_once 'fechData.php';
     include_once 'components/header.php';
     ?>

    <!-- Header Start -->
    <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class="display-4 text-white text-uppercase">Blog Detail</h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase"><a class="text-white" href="">Home</a></p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Blog Detail</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- Blog Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row">
            <?php
// Assuming $conn is your database connection

// Fetch the latest blog entry
$query = "SELECT * FROM blogs ORDER BY publishDate DESC LIMIT 1";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    // Fetch the latest blog entry
    $row = $result->fetch_assoc();

    // Extract data from the fetched row
    $firstImage = htmlspecialchars($row['firstImage']);
    $day = htmlspecialchars(date('d', strtotime($row['publishDate'])));
    $month = htmlspecialchars(date('F', strtotime($row['publishDate'])));
    $mainHeading = htmlspecialchars($row['mainHeading']);
    $istPara = htmlspecialchars($row['firstParagraph']);
    $secondPara = htmlspecialchars($row['secondParagraph']);
    $istSubHeading = htmlspecialchars($row['firstSubheading']);
    $secondImage = htmlspecialchars($row['secondImage']);
    $thirdPara = htmlspecialchars($row['thirdParagraph']);
    $secondSubHeading = htmlspecialchars($row['secondSubheading']);
    $thirdImage = htmlspecialchars($row['thirdImage']);
    $forthPara = htmlspecialchars($row['fourthParagraph']);

    // Output the blog details in the HTML structure
    echo '
    <div class="col-lg-8">
        <!-- Blog Detail Start -->
        <div class="pb-3">
            <div class="blog-item">
                <div class="position-relative">
                    <img class="img-fluid w-100" src="img/' . $firstImage . '" alt="">
                    <div class="blog-date">
                        <h6 class="font-weight-bold mb-n1">' . $day . '</h6>
                        <small class="text-white text-uppercase">' . $month . '</small>
                    </div>
                </div>
            </div>
            <div class="bg-white mb-3" style="padding: 30px;">
                <div class="d-flex mb-3">
                    <p class="text-primary text-uppercase text-decoration-none">Admin</p>
                    <span class="text-primary px-2">|</span>
                    <p class="text-primary text-uppercase text-decoration-none">' . htmlspecialchars($_SESSION['managerName']) . '</p>
                </div>
                <h2 class="mb-3">' . $mainHeading . '</h2>
                <p>' . $istPara . '</p>
                <p>' . $secondPara . '</p>
                <h4 class="mb-3">' . $istSubHeading . '</h4>
                <img class="img-fluid w-50 float-left mr-4 mb-2" src="img/' . $secondImage . '">
                <p>' . $thirdPara . '</p>
                <h5 class="mb-3">' . $secondSubHeading . '</h5>
                <img class="img-fluid w-50 float-right ml-4 mb-2" src="img/' . $thirdImage . '">
                <p>' . $forthPara . '</p>
            </div>
        </div>
        <!-- Blog Detail End -->
    </div>';
} else {
    echo 'No blog available';
}
?>

    
                <div class="col-lg-4 mt-5 mt-lg-0">
                    <!-- Author Bio -->
                    <div class="d-flex flex-column text-center bg-white mb-5 py-5 px-4">
                        <img src="img/<?php echo $_SESSION['managerDp']; ?>" class="img-fluid mx-auto mb-3" style="width: 100px;">
                        <h3 class="text-primary mb-3"><?php echo $_SESSION['managerName']; ?></h3>
                        <p>Explore global destinations with our expert tours and travel services, specializing in unforgettable Hajj and Umrah pilgrimages. Experience exceptional journeys with us.</p>
                        <div class="d-flex justify-content-center">
                            <a class="text-primary px-2" target="_blank" href="<?php echo $_SESSION['managerFb']; ?>">
                                <i class="fab fa-facebook -f"></i>
                            </a>
                            <a class="text-primary px-2" target="_blank" href="<?php echo $_SESSION['managerWhatsapp']; ?>">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                        </div>

                    </div>
                   
                </div>
            </div>
        </div>
    </div>
    <!-- Blog End -->


    <!-- Footer Start -->
    <?php include_once 'forms.php';
    include_once 'components/footer.php';?>
</body>

</html>