<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>KHADIM UL MADINAH</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="TOUR AND TRAVEL" name="keywords">
    <meta content="Tour and Travel" name="description">

    <!-- Favicon -->
    <link href="img/logo favicon.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body onload="setActivePage('testimonial-link')">
<?php 
     include_once 'connection.php';
     include_once 'fechData.php';
     include_once 'components/header.php';
     ?>

    <!-- Header Start -->
    <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class="display-4 text-white text-uppercase">Testimonial</h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase"><a class="text-white" href="">Home</a></p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Testimonial</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->
     
    <!-- Testimonial Start -->
    <div id="testimonial" class="container-fluid py-5">
        <div class="container py-5">

            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Testimonial</h6>
                <h1>What Say Our Clients</h1>
            </div>

            <div class="owl-carousel testimonial-carousel">

            <?php
$sql = "SELECT * FROM testimonials";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $name = htmlspecialchars($row['name']);
        $profession = htmlspecialchars($row['profession']);
        $comment = htmlspecialchars($row['comment']);
        $dp = htmlspecialchars($row['dp']);
        ?>
        <div class="text-center pb-4">
            <img class="img-fluid mx-auto" src="img/<?php echo $dp; ?>" style="width: 100px; height: 100px;" >
            <div class="testimonial-text bg-white p-4 mt-n5">
                <p class="mt-5"><?php echo $comment; ?></p>
                <h5 class="text-truncate"><?php echo $name; ?></h5>
                <span><?php echo $profession; ?></span>
            </div>
        </div>
        <?php
    }
} else {
    echo "No testimonials found.";
}
?>

            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    <!-- Footer Start -->
    <?php include_once 'forms.php';
    include_once 'components/footer.php';?>
</body>

</html>