    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 py-5 px-sm-3 px-lg-5" style="margin-top: 90px;">
        <div class="row pt-5 d-flex align-items-center justify-content-center">
            <div class="col-lg-3 col-md-6 mb-5">
                <a href="" class="navbar-brand">
                    <img src="./img/" alt="">
                    <h2 class="text-primary">KHADIM <span class="text-white">UL</span> MADINA</h1>
                </a>
                <p>Explore global destinations with our expert tours and travel services, specializing in unforgettable Hajj and Umrah pilgrimages. Experience exceptional journeys with us.</p>
                <h6 class="text-white text-uppercase mt-4 mb-3" style="letter-spacing: 5px;">Follow Us</h6>
                <div class="d-flex justify-content-start">
                    <a target="_blank" class="btn btn-outline-primary btn-square mr-2" href="<?php echo $_SESSION['managerWhatsapp']; ?>"><i class="fab fa-whatsapp"></i> </a>
                    <a target="_blank" class="btn btn-outline-primary btn-square mr-2" href="<?php echo $_SESSION['managerFb']; ?>"><i class="fab fa-facebook-f"></i></a>
                    <a target="_blank" class="btn btn-outline-primary btn-square" href="<?php echo $_SESSION['managerInsta']; ?>"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="text-white text-uppercase mb-4" style="letter-spacing: 5px;">Usefull Links</h5>
                <div class="d-flex flex-column justify-content-start">
                    <a class="text-white-50 mb-2" href="about.php"><i class="fa fa-angle-right mr-2"></i>About</a>
                    <a class="text-white-50 mb-2" href="service.php"><i class="fa fa-angle-right mr-2"></i>Services</a>
                    <a class="text-white-50 mb-2" href="package.php"><i class="fa fa-angle-right mr-2"></i>Packages</a>
                    <a class="text-white-50 mb-2" href="guide.php"><i class="fa fa-angle-right mr-2"></i>Guides</a>
                    <a class="text-white-50 mb-2" href="testimonial.php"><i class="fa fa-angle-right mr-2"></i>Testimonial</a>
                    <a class="text-white-50" href="single.php"><i class="fa fa-angle-right mr-2"></i>Blog</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <h5 class="text-white text-uppercase mb-4" style="letter-spacing: 5px;">Contact Us</h5>
                <p><i class="fa fa-map-marker-alt mr-2"></i>
                <a href="https://maps.app.goo.gl/huScvKb3q2ecVRvEA" target="_blank">Odura road Nillow Kulgam</a>
</p>
                
                <p><i class="fa fa-phone-alt mr-2"></i><a href="tel:+91<?php echo $_SESSION['managerNumber']; ?>">Call</a></p>
                <p><i class="fa fa-envelope mr-2"></i><a href="mailto:<?php echo $_SESSION['managerEmail']; ?>">Mail</a></p>
                <div class="w-100">
                    <form id="subscribeEmailForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="input-group">
                            <input type="email" name="email" class="form-control border-light" style="padding: 25px;" placeholder="Your Email">
                            <div class="input-group-append">
                                <button id="subscribeEmail" name="subscribe" type="submit" class="btn btn-primary px-3">Subscribe email</button>
                            </div> 
                        </div>
                    </form>
                   
                    
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-white border-top py-4 px-sm-3 px-md-5 d-flex align-items-center justify-content-center" style="border-color: rgba(256, 256, 256, .1) !important;">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="text-center text-md-center mb-3 mb-md-0">
                <div class="m-0 text-white-50">
                    <p>Copyright &copy; 
                        <i id="year"></i>
                        <script>
                          document.querySelector("#year").innerHTML =  new Date().getFullYear();
                        </script>
                    </p>
                    <p><?php echo htmlspecialchars($_SESSION["domain"]); ?></p>
                    <p>All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    