<!-- Topbar Start -->
  <!-- Message box start -->
  <div style="position:fixed; z-index:3000; top:50%; left:50%; transform:translate(-50%,-50%);" id="message" class=" container d-none">
        <div class="row justify-content-center">
          <div class="col-12 col-md-6 col-lg-4">
            <div class="centered-div bg-light p-3">
              <p>This is a msg</p>
            </div>
          </div>
        </div>
      </div>
     <!-- Message box end -->
<script src="./js/funs.js"></script>
<div class="container-fluid bg-light pt-3 d-none d-lg-block">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 text-center text-lg-left mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center">
                    <p> <a target="_blank" href="mailto:<?php echo $_SESSION['managerEmail']; ?>"><i class="fa fa-envelope mr-2"></i></a></p>
                    <p class="text-body px-3">|</p>
                    <p><a target="_blank" href="tel:+91<?php echo $_SESSION['managerNumber']; ?>"><i class="fa fa-phone-alt mr-2"></i></a></p>
                    <p class="text-body px-3">|</p>
                    <p><a target="_blank" href="<?php echo $_SESSION['managerWhatsapp']; ?>"><i class="fab fa-whatsapp mr-2"></i></a></p>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a target="_blank" class="text-primary px-3" href="<?php echo $_SESSION['managerFb']; ?>">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-primary px-3" href="<?php echo $_SESSION['managerInsta']; ?>">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Topbar End -->


<!-- Navbar Start -->
<div class="container-fluid position-relative nav-bar p-0">
    <div class="container-lg position-relative p-0 px-lg-3" style="z-index: 9;">
        <nav class="navbar navbar-expand-lg bg-light navbar-light shadow-lg py-3 py-lg-0 pl-3 pl-lg-5">
                <a href="http://localhost/toursite/index.php"><img src="img/logo white.png" width="150px" alt=""></a> 
               <!-- <h4 class="m-0 text-primary">KHADIM<span class="text-dark"> UL </span> MADINAH</h1> -->
           
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
                <div class="navbar-nav ml-auto py-0">
                    <a id="home-link" href="index.php" class="nav-item nav-link">Home</a>
                    <a id="package-link" href="package.php" class="nav-item nav-link">Tour Packages</a>
                    <a id="service-link" href="service.php" class="nav-item nav-link">Services</a>
                    <a id="about-link" href="about.php" class="nav-item nav-link">About</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu border-0 rounded-0 m-0">
                            <a id="single-link" href="single.php" class="dropdown-item">Blog Detail</a>
                            <a id="destination-link" href="destination.php" class="dropdown-item">Destination</a>
                            <a id="guide-link" href="guide.php" class="dropdown-item">Travel Guides</a>
                            <a id="testimonial-link" href="testimonial.php" class="dropdown-item">Testimonial</a>
                        </div>
                    </div>
                    <a id="contact-link" href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Navbar End -->