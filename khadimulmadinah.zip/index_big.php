<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <title>KHADIM UL MADINAH</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="TOUR AND TRAVEL" name="keywords">
    <meta content="Khadim Ul Madinah" name="description">
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon -->
    <link href="img/logo white.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body onload="setActivePage('home-link')">
    <?php 
     include_once 'connection.php';
     include_once 'fechData.php';
     include_once 'components/header.php';
     ?>
    <!-- Carousel Start -->
    <div class="container-fluid p-0">
        <div id="header-carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/carousel-1.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                        <h2 class="text-white mb-md-4" style="opacity: 0.5;">And complete the Hajj and umrah for Allah<br>2:196</h2>
                        <a href="#booking" class="btn btn-primary py-md-3 px-md-5 mt-2">Book Now</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/carousel-2.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                        <h2 class="text-white mb-md-4" style="opacity: 0.5;">And [mention] when We made the House a place of return for the people and [a place of] security.<br>2:125</h2>
                        <a href="#booking" class="btn btn-primary py-md-3 px-md-5 mt-2">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-prev-icon mb-n2"></span>
                </div>
            </a>
            <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-next-icon mb-n2"></span>
                </div>
            </a>
        </div>
    </div>
    <!-- Carousel End -->

    <!-- About Start -->
    <div id="about" class="container-fluid py-5">
        <div class="container pt-5">
            <div class="row">
                <div class="col-lg-6" style="min-height: 500px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100" src="img/about.jpg" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 pt-5 pb-lg-5">
                    <div class="about-text bg-white p-4 p-lg-5 my-lg-5">
                        <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">About Us</h6>
                        <h1 class="mb-3">We Provide Best Tour Packages In Your Budget</h1>
                        <p>Experience the journey of a lifetime with our affordable tour and travel packages. Whether you're visiting sacred sites like Mecca and Medina for Hajj and Umrah or exploring iconic landmarks around the world, such as the Taj Mahal, Qutub Minar, Red Fort, Jaipur’s Amber Fort, Mysore Palace, the Gateway of India, Hawa Mahal, and the Ajanta and Ellora Caves, we ensure a seamless and enriching experience. We offer comprehensive travel services across the globe, providing comfort, guidance, and peace of mind every step of the way.</p>
                        <div class="row mb-4">
                            <div class="col-6">
                                <img class="img-fluid" src="img/about-1.jpg" alt="">
                            </div>
                            <div class="col-6">
                                <img class="img-fluid" src="img/about-2.jpg" alt="">
                            </div>
                        </div>
                        <a href="#booking" class="btn btn-primary mt-1">Book Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Feature Start -->
    <div class="container-fluid pb-5">
        <div class="container pb-5">
            <div class="row">
                <div class="col-md-4">
                    <div class="d-flex mb-4 mb-lg-0">
                        <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-primary mr-3" style="height: 100px; width: 100px;">
                            <i class="fa fa-2x fa-money-check-alt text-white"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <h5 class="">Competitive Pricing</h5>
                            <p class="m-0">Enjoy unbeatable rates on our Hajj and Umrah packages. We offer the best value for a spiritually enriching journey without compromising on quality.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex mb-4 mb-lg-0">
                        <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-primary mr-3" style="height: 100px; width: 100px;">
                            <i class="fa fa-2x fa-award text-white"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <h5 class="">Best Services</h5>
                            <p class="m-0">Receive top-notch service from start to finish. Our experienced team ensures a smooth and fulfilling pilgrimage experience, catering to all your needs.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex mb-4 mb-lg-0">
                        <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-primary mr-3" style="height: 100px; width: 100px;">
                            <i class="fa fa-2x fa-globe text-white"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <h5 class="">Worldwide Coverage</h5>
                            <p class="m-0">Access our Hajj and Umrah packages from anywhere in the world. We provide comprehensive support and arrangements for pilgrims globally.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature End -->


    <!-- Destination Start -->
    <div id="destination" class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Sacred Sites of Hajj: A Spiritual Journey</h6>
                <h1>Visit Top Sacred Sites</h1>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="img/destination-1.jpg" alt="">
                        <div class="destination-overlay text-white text-decoration-none">
                            <h5 class="text-white">Makkah</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="img/destination-2.jpg" alt="">
                        <div class="destination-overlay text-white text-decoration-none">
                            <h5 class="text-white">Madinah</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="img/destination-3.jpg" alt="">
                        <div class="destination-overlay text-white text-decoration-none">
                            <h5 class="text-white">Mount Arafat</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="img/destination-4.jpg" alt="">
                        <div class="destination-overlay text-white text-decoration-none">
                            <h5 class="text-white">Mina</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="img/destination-5.jpeg" alt="">
                        <div class="destination-overlay text-white text-decoration-none">
                            <h5 class="text-white">Muzdalifah</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="destination-item position-relative overflow-hidden mb-2">
                        <img class="img-fluid" src="img/destination-6.jpg" alt="">
                        <div class="destination-overlay text-white text-decoration-none">
                            <h5 class="text-white">Cave of Hirrah</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Destination Start -->


    <!-- Service Start -->
    <div id="service" class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Services</h6>
                <h1>Tours & Travel Services</h1>
            </div>
            <div class="row d-flex align-items-center justify-content-center">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="service-item bg-white text-center mb-2 py-5 px-4">
                       <a href="#guide"><i class="fa fa-2x fa-route mx-auto mb-4"></i></a> 
                        <h5 class="mb-2">Travel Guide</h5>
                        <p class="m-0">Uncover hidden gems with expert tips, itineraries, and local insights for unforgettable journeys</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="service-item bg-white text-center mb-2 py-5 px-4">
                        <a href="#booking"><i class="fa fa-2x fa-ticket-alt mx-auto mb-4"></i></a>
                        <h5 class="mb-2">Ticket Booking</h5>
                        <p class="m-0">Book your tickets now for an unforgettable experience!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->


    <!-- Packages Start -->
    <div id="package" class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Packages</h6>
                <h1>Pefect Tour Packages</h1>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                        <img class="img-fluid" src="img/package-1.jpg" alt="">
                        <div class="p-4">
                            <div class="d-flex justify-content-between mb-3">
                                <small class="m-0"><i class="fa fa-map-marker-alt text-primary mr-2"></i>Yousmarg</small>
                                <!-- <small class="m-0"><i class="fa fa-calendar-alt text-primary mr-2"></i>2 days</small> -->
                                <!-- <small class="m-0"><i class="fa fa-user text-primary mr-2"></i>2 Person</small> -->
                            </div>
                            <a class="h5 text-decoration-none" href="">Explore the beauty of Yousmarg</a>
                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.7 <small>(250)</small></h6>
                                    <!-- <h5 class="m-0">Rs 20,500</h5> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                        <img class="img-fluid" src="img/jamamasjid.jpg" alt="">
                        <div class="p-4">
                            <div class="d-flex justify-content-between mb-3">
                                <small class="m-0"><i class="fa fa-map-marker-alt text-primary mr-2"></i>Jama Masjid Delhi</small>
                                <!-- <small class="m-0"><i class="fa fa-calendar-alt text-primary mr-2"></i>1 day</small> -->
                                <!-- <small class="m-0"><i class="fa fa-user text-primary mr-2"></i>2 Person</small> -->
                            </div>
                            <a class="h5 text-decoration-none" href="">Visit Jama Masjid in Delhi, an architectural marvel</a>
                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.5 <small>(491)</small></h6>
                                    <!-- <h5 class="m-0">Rs 10,000</h5> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                        <img class="img-fluid" src="img/tajMahal.jpg" alt="">
                        <div class="p-4">
                            <div class="d-flex justify-content-between mb-3">
                                <small class="m-0"><i class="fa fa-map-marker-alt text-primary mr-2"></i>Taj mahal Agra</small>
                                <!-- <small class="m-0"><i class="fa fa-calendar-alt text-primary mr-2"></i>3 days</small> -->
                                <!-- <small class="m-0"><i class="fa fa-user text-primary mr-2"></i>2 Person</small> -->
                            </div>
                            <a class="h5 text-decoration-none" href="">Experience the timeless beauty of the Taj Mahal</a>
                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.3 <small>(73)</small></h6>
                                    <!-- <h5 class="m-0">25,000</h5> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                        <img class="img-fluid" src="img/package-4.jpg" alt="">
                        <div class="p-4">
                            <div class="d-flex justify-content-between mb-3">
                                <small class="m-0"><i class="fa fa-map-marker-alt text-primary mr-2"></i>Gul marg</small>
                                <!-- <small class="m-0"><i class="fa fa-calendar-alt text-primary mr-2"></i>3 days</small> -->
                                <!-- <small class="m-0"><i class="fa fa-user text-primary mr-2"></i>2 Person</small> -->
                            </div>
                            <a class="h5 text-decoration-none" href="">Experience Gulmarg’s stunning winter landscapes</a>
                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>5.0 <small>(139)</small></h6>
                                    <!-- <h5 class="m-0">28,000</h5> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                        <img class="img-fluid" src="img/shimla.jpg" alt="">
                        <div class="p-4">
                            <div class="d-flex justify-content-between mb-3">
                                <small class="m-0"><i class="fa fa-map-marker-alt text-primary mr-2"></i>Shimla</small>
                                <!-- <small class="m-0"><i class="fa fa-calendar-alt text-primary mr-2"></i>4 days</small> -->
                                <!-- <small class="m-0"><i class="fa fa-user text-primary mr-2"></i>2 Person</small> -->
                            </div>
                            <a class="h5 text-decoration-none" href="">Enjoy Shimla’s charming hill station scenery </a>
                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.9 <small>(225)</small></h6>
                                    <!-- <h5 class="m-0">35,000</h5> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="package-item bg-white mb-2">
                        <img class="img-fluid" src="img/goa.jpg" alt="">
                        <div class="p-4">
                            <div class="d-flex justify-content-between mb-3">
                                <small class="m-0"><i class="fa fa-map-marker-alt text-primary mr-2"></i>Goa</small>
                                <!-- <small class="m-0"><i class="fa fa-calendar-alt text-primary mr-2"></i>2 days</small> -->
                                <!-- <small class="m-0"><i class="fa fa-user text-primary mr-2"></i>2 Person</small> -->
                            </div>
                            <a class="h5 text-decoration-none" href="">Discover the vibrant beaches and rich culture of Goa</a>
                            <div class="border-top mt-4 pt-4">
                                <div class="d-flex justify-content-between">
                                    <h6 class="m-0"><i class="fa fa-star text-primary mr-2"></i>4.1 <small>(370)</small></h6>
                                    <!-- <h5 class="m-0">25,000</h5> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Packages End -->

  <!-- Booking Start -->
<div id="booking" class="container-fluid bg-registration py-5" style="margin: 90px 0;">
    <div class="container py-5">
        <div class="row align-items-center">
            <div class="col-lg-7 mb-5 mb-lg-0">
                <div class="mb-4">
                    <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Mega Offer</h6>
                    <h1 class="text-white"><span class="text-primary">20% OFF</span> For Students</h1>
                </div>
                <p class="text-white">Uncover hidden treasures and unique destinations across the globe with personalized adventures crafted to fit your interests. Benefit from our seamless, all-inclusive planning for a smooth journey from start to finish. Enjoy amazing global travel experiences at budget-friendly prices and embark on your worldwide journey starting right here.
                    dolor</p>
                <ul class="list-inline text-white m-0">
                    <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Exceptional experiences without breaking the bank</li>
                    <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Enjoy hassle-free travel with our all-inclusive planning services.</li>
                    <li class="py-2"><i class="fa fa-check text-primary mr-3"></i>Start your adventure from here and see the globe like never before</li>
                </ul>
            </div>
            <div class="col-lg-5">
                <div class="card border-0">
                    <div class="card-header bg-primary text-center p-4">
                        <h1 class="text-white m-0">Book Now</h1>
                    </div>
                    <div class="card-body rounded-bottom bg-white p-5">

                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control p-4" name="name" placeholder="Your name" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="number" class="form-control p-4" name="number" placeholder="Your number" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control p-4" name="email" placeholder="Your email" required="required" />
                            </div>
                            <div class="form-group">
                                <input id="travelDate" title="Date of travel" type="date" min="<?php echo date('Y-m-d'); ?>" class="form-control p-4" name="travelDate" placeholder="Travel Date" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control p-4" name="destination" placeholder="Destination" required="required" />
                            </div>
                            <div>
                                <button class="btn btn-primary btn-block py-3" name="bookBtn" value="bookBtn" type="submit">Book</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Booking End -->

 <!-- Manager Start -->
 <div id="manager" class="manager container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Manager</h6>
                <!-- <h1>Manager</h1> -->
            </div>
            <div class="row d-flex align-items-center justify-content-center">
                <div class="col-lg-3 col-md-4 col-sm-6 pb-2">
                    <div class="team-item bg-white mb-4">
                        <div class="team-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="img/<?php echo $_SESSION['managerDp']; ?>" alt="">
                            <div class="team-social">
                                <a class="btn btn-outline-primary btn-square" target="_blank" href="<?php echo $_SESSION['managerWhatsapp'] ; ?>"><i class="fab fa-whatsapp"></i></a>
                                <a class="btn btn-outline-primary btn-square" target="_blank" href="<?php echo $_SESSION['managerFb']; ?>"><i class="fab fa-facebook-f"></i></a>
                                <!-- <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-instagram"></i></a> -->
                                <!-- <a class="btn btn-outline-primary btn-square" href=""><i class="fab fa-linkedin-in"></i></a> -->
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <h5 class="text-truncate"><?php echo $_SESSION['managerName']; ?></h5>
                            <p class="m-0">s/o <?php echo $_SESSION['managerFather']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Manager End -->

    <!-- Team Start -->
    <div id="guide" class="container-fluid py-5">
        <div class="container pt-5 pb-3">

            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Guides</h6>
                <h1>Our Travel Guides</h1>
            </div>

            <div class="row d-flex align-items-center justify-content-center">

            <?php
// Fetch data from guides table
$sql = "SELECT name, designation, dp,whatsapp,fb FROM guides";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $name = htmlspecialchars($row['name']);
        $designation = htmlspecialchars($row['designation']);
        $dp = htmlspecialchars($row['dp']);
        $whatsapp = htmlspecialchars($row['whatsapp']);
        $fb = htmlspecialchars($row['fb']);

        echo '
        <div class="col-lg-3 col-md-4 col-sm-6 pb-2">
            <div class="team-item bg-white mb-4">
                <div class="team-img position-relative overflow-hidden">
                    <img class="img-fluid w-100" src="img/' . $dp . '" alt="">
                    <div class="team-social">
                        <a class="btn btn-outline-primary btn-square" target="_blank" href="' . $whatsapp . '"><i class="fab fa-whatsapp"></i></a>
                        <a class="btn btn-outline-primary btn-square" target="_blank" href="' . $fb . '"><i class="fab fa-facebook-f"></i></a>
                    </div>
                </div>
                <div class="text-center py-4">
                    <h5 class="text-truncate">' . $name . '</h5>
                    <p class="m-0">' . $designation . '</p>
                </div>
            </div>
        </div>';
    }
} else {
    echo 'No guides found';
}
?>


            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div id="testimonial" class="container-fluid py-5">
        <div class="container py-5">

            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Testimonial</h6>
                <h1>What Our Clients Say</h1>
            </div>

            <div class="owl-carousel testimonial-carousel">

            <?php
$sql = "SELECT * FROM testimonials";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $name = htmlspecialchars($row['name']);
        $profession = htmlspecialchars($row['profession']);
        $comment = htmlspecialchars($row['comment']);
        $dp = htmlspecialchars($row['dp']);
        ?>
        <div class="text-center pb-4">
            <img class="img-fluid mx-auto" src="img/<?php echo $dp; ?>" style="width: 100px; height: 100px;" >
            <div class="testimonial-text bg-white p-4 mt-n5">
                <p class="mt-5"><?php echo $comment; ?></p>
                <h5 class="text-truncate"><?php echo $name; ?></h5>
                <span><?php echo $profession; ?></span>
            </div>
        </div>
        <?php
    }
} else {
    echo "No testimonials found.";
}
?>

            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    <!-- Blog Start -->
    <div id="blog" class="container-fluid py-5">
        <div class="container pt-5 pb-3">

            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Our Blog</h6>
                <h1>Latest From Our Blog</h1>
            </div>

            <div class="row pb-3 d-flex align-items-center justify-content-center">

            <?php

// Query to fetch all data from the latestblog table
$query = "SELECT * FROM blogs";
$result = mysqli_query($conn, $query);

if ($result) {
    // Check if there are any rows returned
    if (mysqli_num_rows($result) > 0) {
        // Loop through each row in the result set
        while ($row = mysqli_fetch_assoc($result)) {
            $image = htmlspecialchars($row['firstImage']);
            $date = htmlspecialchars(date('d', strtotime($row['publishDate'])));
            $month = htmlspecialchars(date('F', strtotime($row['publishDate'])));
            $admin = htmlspecialchars($row['admin']);
            $text = htmlspecialchars($row['heading']);
            
            // Output the HTML with the fetched data
            echo '
            <div class="col-lg-4 col-md-6 mb-4 pb-2">
                <div class="blog-item">
                    <div class="position-relative">
                    <a href="single.php" target="_blank"><img class="img-fluid w-100" src="img/' . $image . '" alt=""></a>
                        <div class="blog-date">
                            <h6 class="font-weight-bold mb-n1">' . $date . '</h6>
                            <small class="text-white text-uppercase">' . $month . '</small>
                        </div>
                    </div>
                    <div class="bg-white p-4">
                        <div class="d-flex mb-2">
                            <p class="text-primary text-uppercase text-decoration-none" href="#">Admin | ' . $admin . '</p>
                        </div>
                        <p class="h5 m-0 text-decoration-none" href="#">' . $text . '</p>
                    </div>
                </div>
            </div>';
        }
    } else {
        // No records found
        echo '<p>No blog yet</p>';
    }
} else {
    // Handle query error
    echo "Error: " . mysqli_error($conn);
}
?>



            </div>
        </div>
    </div>
    <!-- Blog End -->

    <?php 
     include_once 'forms.php';
     include_once 'components/footer.php';
     // Close the connection
     mysqli_close($conn);
     ?>
</body>

</html>