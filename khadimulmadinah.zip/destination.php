<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <title>KHADIM UL MADINAH</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="TOUR AND TRAVEL" name="keywords">
    <meta content="Tour and Travel" name="description">

    <!-- Favicon -->
    <link href="img/logo favicon.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body onload="setActivePage('destination-link')">
<?php 
     include_once 'connection.php';
     include_once 'fechData.php';
     include_once 'components/header.php';
     ?>

    <!-- Header Start -->
    <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class="display-4 text-white text-uppercase">Destination</h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase"><a class="text-white" href="">Home</a></p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Destination</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End --> 

    <!-- Destination Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <div class="text-center mb-3 pb-3">
                <h6 class="text-primary text-uppercase" style="letter-spacing: 5px;">Destination</h6>
                <h1>Explore Top Destination</h1>
            </div>
            <div class="row d-flex align-items-center justify-content-center">

            <?php

// Fetch records from the destination table
$query = "SELECT pic, name, cities FROM destinations";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $pic = htmlspecialchars($row['pic']);
        $name = htmlspecialchars($row['name']);
        $cities = htmlspecialchars($row['cities']);
        
        echo '
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="destination-item position-relative overflow-hidden mb-2">
                <img class="img-fluid" src="img/' . $pic . '" alt="">
                <a class="destination-overlay text-white text-decoration-none" href="">
                    <h5 class="text-white">' . $name . '</h5>
                    <span>' . $cities . ' Cities</span>
                </a>
            </div>
        </div>';
    }
} else {
    echo 'No data available';
}
?>


            </div>
        </div>
    </div>
    <!-- Destination Start -->


    <!-- Footer Start -->
    <?php include_once 'forms.php';
    include_once 'components/footer.php';?>
</body>

</html>