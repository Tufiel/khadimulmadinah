<?php
session_start();
unset($_SESSION['loggedIn']); // Clear the session variable
session_destroy(); // End the session

header("Location: login.php"); // Redirect to a different page, if necessary
exit();
?>
