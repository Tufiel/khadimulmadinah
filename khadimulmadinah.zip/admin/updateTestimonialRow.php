<?php
include_once '../connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];

    if ($action === 'ADD') {
        $name = $_POST['name'];
        $comment = $_POST['comment'];
        $dp = $_POST['dp'];
        $profession = $_POST['profession'];

        $sql = "INSERT INTO testimonials (name, comment, dp, profession) VALUES ('$name', '$comment', '$dp', '$profession')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Record added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error adding record: " . $conn->error]);
        }
    } elseif ($action === 'UPDATE') {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $comment = $_POST['comment'];
        $dp = $_POST['dp'];
        $profession = $_POST['profession'];

        $sql = "UPDATE testimonials SET name='$name', comment='$comment', dp='$dp', profession='$profession' WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Updated successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error updating record: " . $conn->error]);
        }
    } elseif ($action === 'DELETE') {
        $id = $_POST['id'];
        $sql = "DELETE FROM testimonials WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Record deleted successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error deleting record: " . $conn->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid action"]);
    }
}
?>
