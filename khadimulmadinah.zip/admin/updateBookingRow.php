<?php
include_once '../connection.php';

header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? null;

    if ($action === 'ADD') {
        $name = $conn->real_escape_string($_POST['name']);
        $number = $conn->real_escape_string($_POST['number']);
        $email = $conn->real_escape_string($_POST['email']);
        $destination = $conn->real_escape_string($_POST['destination']);
        $traveldate = $conn->real_escape_string($_POST['traveldate']);
        $orderdate = $conn->real_escape_string($_POST['orderdate']);

        $sql = $conn->prepare("INSERT INTO bookings (name, number, email, destination, traveldate, orderdate) VALUES (?, ?, ?, ?, ?, ?)");
        $sql->bind_param("ssssss", $name, $number, $email, $destination, $traveldate, $orderdate);

        if ($sql->execute()) {
            echo json_encode(["status" => "success", "message" => "Record added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error adding record: " . $conn->error]);
        }
        $sql->close();
    } elseif ($action === 'UPDATE') {
        $id = $conn->real_escape_string($_POST['id']);
        $name = $conn->real_escape_string($_POST['name']);
        $number = $conn->real_escape_string($_POST['number']);
        $email = $conn->real_escape_string($_POST['email']);
        $destination = $conn->real_escape_string($_POST['destination']);
        $traveldate = $conn->real_escape_string($_POST['traveldate']);
        $orderdate = $conn->real_escape_string($_POST['orderdate']);

        $sql = $conn->prepare("UPDATE bookings SET name=?, number=?, email=?, destination=?, traveldate=?, orderdate=? WHERE id=?");
        $sql->bind_param("ssssssi", $name, $number, $email, $destination, $traveldate, $orderdate, $id);

        if ($sql->execute()) {
            echo json_encode(["status" => "success", "message" => "Record updated successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error updating record: " . $conn->error]);
        }
        $sql->close();
    } elseif ($action === 'DELETE') {
        $id = $conn->real_escape_string($_POST['id']);

        $sql = $conn->prepare("DELETE FROM bookings WHERE id=?");
        $sql->bind_param("i", $id);

        if ($sql->execute()) {
            echo json_encode(["status" => "success", "message" => "Record deleted successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error deleting record: " . $conn->error]);
        }
        $sql->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid action"]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $today = date('Y-m-d');
    $thisWeekStart = date('Y-m-d', strtotime('last Monday', strtotime($today)));
    $thisMonthStart = date('Y-m-01');
    $thisYearStart = date('Y-01-01');

    $queries = [
        'thisWeek' => "SELECT COUNT(*) as count FROM bookings WHERE orderdate >= '$thisWeekStart'",
        'thisMonth' => "SELECT COUNT(*) as count FROM bookings WHERE orderdate >= '$thisMonthStart'",
        'thisYear' => "SELECT COUNT(*) as count FROM bookings WHERE orderdate >= '$thisYearStart'",
        'total' => "SELECT COUNT(*) as count FROM bookings"
    ];

    $results = [];
    foreach ($queries as $key => $query) {
        $result = $conn->query($query);
        if ($result) {
            $results[$key] = $result->fetch_assoc()['count'];
        } else {
            $results[$key] = 0;
        }
    }

    echo json_encode($results);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}

$conn->close();
?>
