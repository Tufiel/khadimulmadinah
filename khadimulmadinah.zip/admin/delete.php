<?php
include_once '../connection.php';

if (isset($_GET['table']) && isset($_GET['id'])) {
    $table = $_GET['table'];
    $id = $_GET['id'];

    // Validate the table name to prevent SQL injection
    $validTables = ['queries', 'another_table']; // List of valid tables
    if (!in_array($table, $validTables)) {
        echo json_encode(["status" => "error", "message" => "Invalid table name"]);
        exit;
    }

    // Delete query
    $sql = "DELETE FROM $table WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Record deleted successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error deleting record: " . $conn->error]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
?>
