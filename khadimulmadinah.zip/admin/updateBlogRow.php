<?php
include_once '../connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];

    if ($action === 'ADD') {
        $firstImage = $_POST['firstImage'];
        $mainHeading = $_POST['mainHeading'];
        $firstParagraph = $_POST['firstParagraph'];
        $secondParagraph = $_POST['secondParagraph'];
        $firstSubheading = $_POST['firstSubheading'];
        $secondImage = $_POST['secondImage'];
        $thirdParagraph = $_POST['thirdParagraph'];
        $secondSubheading = $_POST['secondSubheading'];
        $thirdImage = $_POST['thirdImage'];
        $fourthParagraph = $_POST['fourthParagraph'];
        $publishDate = $_POST['publishDate'];
        $admin = $_POST['admin'];
        $heading = $_POST['heading'];

        $sql = "INSERT INTO blogs (firstImage, mainHeading, firstParagraph, secondParagraph, firstSubheading, secondImage, thirdParagraph, secondSubheading, thirdImage, fourthParagraph, publishDate, admin, heading) VALUES ('$firstImage', '$mainHeading', '$firstParagraph', '$secondParagraph', '$firstSubheading', '$secondImage', '$thirdParagraph', '$secondSubheading', '$thirdImage', '$fourthParagraph', '$publishDate', '$admin', '$heading')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Record added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error adding record: " . $conn->error]);
        }
    } elseif ($action === 'UPDATE') {
        $id = $_POST['id'];
        $firstImage = $_POST['firstImage'];
        $mainHeading = $_POST['mainHeading'];
        $firstParagraph = $_POST['firstParagraph'];
        $secondParagraph = $_POST['secondParagraph'];
        $firstSubheading = $_POST['firstSubheading'];
        $secondImage = $_POST['secondImage'];
        $thirdParagraph = $_POST['thirdParagraph'];
        $secondSubheading = $_POST['secondSubheading'];
        $thirdImage = $_POST['thirdImage'];
        $fourthParagraph = $_POST['fourthParagraph'];
        $publishDate = $_POST['publishDate'];
        $admin = $_POST['admin'];
        $heading = $_POST['heading'];

        $sql = "UPDATE blogs SET firstImage='$firstImage', mainHeading='$mainHeading', firstParagraph='$firstParagraph', secondParagraph='$secondParagraph', firstSubheading='$firstSubheading', secondImage='$secondImage', thirdParagraph='$thirdParagraph', secondSubheading='$secondSubheading', thirdImage='$thirdImage', fourthParagraph='$fourthParagraph', publishDate='$publishDate', admin='$admin', heading='$heading' WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Updated successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error updating record: " . $conn->error]);
        }
    } elseif ($action === 'DELETE') {
        $id = $_POST['id'];
        $sql = "DELETE FROM blogs WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Record deleted successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error deleting record: " . $conn->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid action"]);
    }
}
?>
