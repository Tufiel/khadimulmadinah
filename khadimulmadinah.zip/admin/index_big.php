<?php 

session_start();
include_once '../fechData.php';

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['logout'])) {
    unset($_SESSION['loggedin']); // Clear the session variable
    session_destroy(); // End the session
    header("Location: login.php"); // Redirect to a different page
    exit();
}

// Fetch counts from each table
$manager_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM manager"))['count'];
$subscriber_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM subscribers"))['count'];
$booking_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM bookings"))['count'];
$blog_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM blogs"))['count'];
$guide_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM guides"))['count'];
$destination_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM destinations"))['count'];
$query_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM queries"))['count'];
$testimonial_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM testimonials"))['count'];
$tourpackage_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM tourpackages"))['count'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="shortcut icon" href="...img/logo white.png" type="image/x-icon">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/admin.css">
    
</head>

<body>
   
    <div style="text-align: center;" id="messageBox" class="card d-none">
        <span class="title">😊</span>
        <p class="description">We use cookies to ensure that we give you the best experience on our website. </p>
        <div class="actions">
            <button class="decline">
                Decline
            </button>
            <button class="valid">
                Accept
            </button>
        </div>
     </div>

     <button id="toggle-btn" class="btn btn-primary d-md-none" onclick="toggleSidebar()">☰</button>
<div class="container-fluid">
<div class="row">

    <nav id="sidebar" class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <img src="<?php echo isset($_SESSION['managerDp']) ? '../img/' . $_SESSION['managerDp']  : 'https://cdn-icons-png.flaticon.com/512/4042/4042356.png'; ?>"
                        width="100%" alt="Avatar" class="img-fluid rounded-circle mx-auto d-block my-4">
                    <hr style="border:1px solid gray;" class="my-4">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('dashboard')">Dashboard
                        <li class="fa fa-server"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('blog')">Blogs
                        <li class="fa fa-blog"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('bookings')">Bookings
                        <li class="fa fa-car"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('subscribers')">Subscribers
                        <li class="fa fa-users"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('destinations')">Destinations
                        <li class="fa fa-map-marked-alt"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('guides')">guides
                        <li class="fa fa-book"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('manager')">Manager
                        <li class="fa fa-user"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('testimonials')">Testimonials
                        <li class="fa fa-server"></li></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('packages')">Tour Packages <i
                                    class="fa fa-gift"></i></button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link btn btn-light" onclick="showDiv('queries')">Queries <i
                                    class="fa fa-question-circle"></i></button>
                        </li>
                        <li class="nav-item mt-2">
                        <form class="pb-5" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <button id="signoutBtn" type="submit" name="logout">Logout <i class="fab fa-sign-out"></i></button>
</form>

                        </li>
                    </ul>
                </div>
    </nav>

<main id="mainDiv" role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

 <!-- DASHBOARD SECTION STARTS FROM HERE------------------------------ -->

                <div id="dashboard" class="content">
                    <h2 style="text-align: center;">Dashboard</h2>
                

                    <div class="box-container">
                        <div class="box">
                            Subscribers
                            <br>
                            <h2>
                                <?php echo $subscriber_count; ?>
                            </h2>
                            <i class="fa fa-users"></i>
                        </div>

                        <div class="box">
                            Bookings
                            <br>
                            <h2>
                                <?php echo $booking_count; ?>
                            </h2>
                            <i class="fa fa-car"></i>
                        </div>

                        <div class="box">
                            Blogs
                            <br>
                            <h2>
                                <?php echo $blog_count; ?>
                            </h2>
                            <i class="fa fa-blog"></i>
                        </div>

                        <div class="box">
                            Guides
                            <br>
                            <h2>
                                <?php echo $guide_count; ?>
                            </h2>
                            <i class="fa fa-book"></i>
                        </div>

                        <div class="box">
                            Destinations
                            <br>
                            <h2>
                                <?php echo $destination_count; ?>
                            </h2>
                            <i class="fa fa-map-marked-alt"></i>
                        </div>

                        <div class="box">
                            Queries
                            <br>
                            <h2>
                                <?php echo $query_count; ?>
                            </h2>
                            <i class="fa fa-question-circle"></i>
                        </div>

                        <div class="box">
                            Testimonials
                            <br>
                            <h2>
                                <?php echo $testimonial_count; ?>
                            </h2>
                            <i class="fa fa-comments"></i>
                        </div>

                        <div class="box">
                            Tour Packages
                            <br>
                            <h2>
                                <?php echo $tourpackage_count; ?>
                            </h2>
                            <i class="fa fa-gift"></i>
                        </div>

                        <div id="uploadDiv"
                            class="width-full d-flex flex-column align-items-center justify-content-center">
                            <b>Upload Image</b>
                            <br>
                            <form action="upload.php" method="post" enctype="multipart/form-data"
                                class="d-flex flex-column align-items-center justify-content-center">
                                <input type="file" name="image" id="image" accept=".jpg, .jpeg, .png" required>
                                <br>
                                <input type="text" name="endName" placeholder="Name" id="endName" required>
                                <br>
                                <input type="submit" value="Upload Image" name="submit">
                            </form>
                        </div>

                    </div>


                </div>
 <!-- DASHBOARD SECTION END HERE------------------------------ -->

 <!-- BLOG SECTION STARTS FROM HERE------------------------------ -->

    <div id="blog" class="content d-none">

        <h2 style="text-align: center;">Blogs Table</h2>
        <div class="table-responsive mt-5">
            <table class="text-center table table-striped table-bordered mt-7">
                <thead>
                 <tr>
                    <th>ID</th>
                    <th>First Image</th>
                    <th>Main Heading</th>
                    <th>First Paragraph</th>
                    <th>Second Paragraph</th>
                    <th>First Subheading</th>
                    <th>Second Image</th>
                    <th>Third Paragraph</th>
                    <th>Second Subheading</th>
                    <th>Third Image</th>
                    <th>Fourth Paragraph</th>
                    <th>Publish Date</th>
                    <th>Admin Name</th>
                    <th>Heading</th>
                    <th colspan="2">Action</th>
                 </tr>
                </thead>
                <tbody>
                 <tr>
                    <td></td>
                    <td contenteditable='true' data-field='firstImage'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='mainHeading'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='firstParagraph'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='secondParagraph'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='firstSubheading'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='secondImage'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='thirdParagraph'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='secondSubheading'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='thirdImage'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='fourthParagraph'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='publishDate'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='admin'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-field='heading'><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td colspan='2'><button class='btn btn-success btn-sm' onclick='blogRow(this,true,true)'>Add</button></td>
                 </tr>
                <?php
                $sql = "SELECT * FROM blogs";
                $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                        <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='firstImage'>{$row['firstImage']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='mainHeading'>{$row['mainHeading']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='firstParagraph'>{$row['firstParagraph']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='secondParagraph'>{$row['secondParagraph']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='firstSubheading'>{$row['firstSubheading']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='secondImage'>{$row['secondImage']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='thirdParagraph'>{$row['thirdParagraph']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='secondSubheading'>{$row['secondSubheading']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='thirdImage'>{$row['thirdImage']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='fourthParagraph'>{$row['fourthParagraph']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='publishDate'>{$row['publishDate']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='admin'>{$row['admin']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='heading'>{$row['heading']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                <td>
                <button class='btn btn-success btn-sm mb-1' onclick='blogRow(this,true)' data-id='{$row['id']}'>Save</button>
                </td>
                <td>
                <button class='btn btn-danger btn-sm' onclick='blogRow(this,false)' data-id='{$row['id']}'>Delete</button>
                </td>
                </tr>";
            }
                } else {
                echo "<tr><td colspan='15'>No records found</td></tr>";
                }
            ?>
            </tbody>
        </table>

    </div>

    <br><br><br>
  </div>

 <!-- BLOG SECTION ENDS HERE------------------------------ -->

 <!-- BOOKINGS SECTION STARTS FROM HERE------------------------------ -->
                <div id="bookings" class="content d-none">
                    <h2 style="text-align: center;">Bookings</h2>

                    <div class="d-flex justify-content-around align-items-center flex-wrap">
                        <div id="thisWeek" class="box mb-3">This week: 0</div>
                        <div id="thisMonth" class="box mb-3">This month: 0</div>
                        <div id="thisYear" class="box mb-3">This year: 0</div>
                        <div id="total" class="box mb-3">Total: 0</div>
                    </div>

                    <div class="mt-4">
                        <label for="sort">Sort by:</label>
                        <select id="sort" class="form-control d-inline-block w-auto">
                            <option value="name">Name</option>
                            <option value="id">ID</option>
                            <option value="traveldate">Travel Date</option>
                        </select>
                        <select id="order" class="form-control d-inline-block w-auto ml-2">
                            <option value="Asc">Asc</option>
                            <option value="Desc">Desc</option>
                        </select>
                        <!-- <button class="btn btn-primary ml-2" onclick="sortTable()"><i class="fa fa-filter"></i></button> -->

                    </div>
                    <div class="table-responsive mt-5">
                        <table class="text-center table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Number</th>
                                    <th>Email</th>
                                    <th>Destination</th>
                                    <th>Travel Date</th>
                                    <th>Order Date</th>
                                    <th colspan="3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td contenteditable='true' data-field='name'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='number'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='email'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='destination'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td>
                                        <input type='date' class='form-control' data-field='traveldate'>
                                    </td>
                                    <td>
                                        <input type='date' class='form-control' data-field='orderdate'>
                                    </td>
                                    <td colspan="3">
                                        <button class="btn btn-success btn-sm"
                                            onclick="bookingRow(this, true, true)">Add</button>
                                    </td>
                                </tr>
                                <?php
                $sql = "SELECT * FROM bookings ORDER BY id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $traveldate = date('Y-m-d', strtotime($row['traveldate']));
                        $orderdate = date('Y-m-d', strtotime($row['orderdate']));
                        echo "<tr>
                            <td data-field='id'>{$row['id']}</td>
                            <td contenteditable='true' data-id='{$row['id']}' data-field='name'>{$row['name']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                            <td contenteditable='true' data-id='{$row['id']}' data-field='number'>{$row['number']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                            <td contenteditable='true' data-id='{$row['id']}' data-field='email'>{$row['email']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                            <td contenteditable='true' data-id='{$row['id']}' data-field='destination'>{$row['destination']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                            <td><input type='date' class='form-control' value='{$traveldate}' data-id='{$row['id']}' data-field='traveldate' '><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                            <td><input type='date' class='form-control' value='{$orderdate}' data-id='{$row['id']}' data-field='orderdate' '><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                            <td><button class='btn btn-primary btn-sm mb-1' onclick='bookingRow(this, true)' data-id='{$row['id']}'>Update</button></td>
                            <td><button class='btn btn-danger btn-sm' onclick='bookingRow(this, false)' data-id='{$row['id']}'>Delete</button></td>
                            <td><button class='btn btn-danger btn-sm' > <a style='color:white; text-declaration:none;' href='tel:{$row['number']}' >Call</a></button></td>

                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No records found</td></tr>";
                }
                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

 <!-- BOOKINGS SECTION END HERE------------------------------ -->

 <!-- SUBSCRIBERS SECTION STARTS FROM HERE------------------------------ -->

                <div id="subscribers" class="content d-none">
                    <h2 style="text-align: center;">Subscribers</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box">Total:
                            <?php echo $subscriber_count ; ?>
                        </div>
                    </div>
                    <div class="table-responsive mt-5">
                        <table class="text-center table mt-7">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Email</th>
                                    <th>Subscribe Date</th>
                                    <th colspan="3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td contenteditable='true' data-field='email'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='subscribeDate'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td colspan="3">
                                        <button class='btn btn-success btn-sm'
                                            onclick='subscriberRow(this,true,true)'>Add</button>
                                    </td>
                                </tr>
                                <?php
        $sql = "SELECT * FROM subscribers";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='email'>{$row['email']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='subscribeDate'>{$row['subscribeDate']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='subscriberRow(this,true)' data-id='{$row['id']}'>Save</button>
                    </td>
                    <td>
                    <button class='btn btn-danger btn-sm' onclick='subscriberRow(this,false)' data-id='{$row['id']}'>Delete</button>
                    </td>
                    <td>
                    <button class='btn btn-primary btn-sm'><a href='mailto:{$row['email']}' style='color:white' >Mail</a></button>
                    </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>

                    </div>
                </div>
 <!-- SUBSCRIBERS SECTION END HERE------------------------------ -->

 <!-- DESTINATION SECTION STARTS FROM HERE------------------------------ -->

                <div id="destinations" class="content d-none">
                    <h2 style="text-align: center;">Destinations</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box mb-5">Total:
                            <?php echo $destination_count ; ?>
                        </div>

                    </div>
                    <div class="table-responsive ">
                        <table class="text-center table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Pic</th>
                                    <th>Name</th>
                                    <th>Cities</th>
                                    <th colspan='2'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td contenteditable='true' data-field='pic'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='name'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='cities'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td colspan='2'>
                                        <button class='btn btn-success btn-sm'
                                            onclick='destinationRow(this,true,true)'>Add</button>
                                    </td>
                                </tr>
                                <?php
        $sql = "SELECT * FROM destinations";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='pic'>{$row['pic']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='name'>{$row['name']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='cities'>{$row['cities']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='destinationRow(this,true)' data-id='{$row['id']}'>Save</button>
                        </td>
                        <td>
                        <button class='btn btn-danger btn-sm' onclick='destinationRow(this,false)' data-id='{$row['id']}'>Delete</button>
                        </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>

                    </div>
                </div>
 <!-- DESTINATION SECTION ENDS HERE------------------------------ -->

 <!-- GUIDES SECTION START FROM HERE------------------------------ -->

                <div id="guides" class="content d-none">
                    <h2 style="text-align: center;">Guides</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box">Total:
                            <?php echo $guide_count ; ?>
                        </div>

                    </div>
                    <div class="table-responsive mt-5">
                        <table class="text-center table mt-7">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Designation</th>
                                    <th>Dp</th>
                                    <th>Whatsapp</th>
                                    <th>Fb</th>
                                    <th colspan='2'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td contenteditable='true' data-field='name'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='designation'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='dp'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='whatsapp'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='fb'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td colspan='2'>
                                        <button class='btn btn-success btn-sm'
                                            onclick='guideRow(this,true,true)'>Add</button>
                                    </td>
                                </tr>
                                <?php
        $sql = "SELECT * FROM guides";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='name'>{$row['name']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='designation'>{$row['designation']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='dp'>{$row['dp']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='whatsapp'>{$row['whatsapp']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='fb'>{$row['fb']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='guideRow(this,true)' data-id='{$row['id']}'>Save</button>
                        </td>
                        <td>
                        <button class='btn btn-danger btn-sm' onclick='guideRow(this,false)' data-id='{$row['id']}'>Delete</button>
                        </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>

                    </div>
                </div>
 <!-- GUIDES SECTION END HERE------------------------------ -->

 <!-- MANAGER SECTION STARTS FROM HERE------------------------------ -->

                <div id="manager" class="content d-none">
                    <h2 style="text-align: center;">Manager</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box">Total:
                            <?php echo $manager_count; ?>
                        </div>
                    </div>
                    <div class="table-responsive mt-5">
                        <table class="text-center table mt-7">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Father Name</th>
                                    <th>Dp</th>
                                    <th>Whatsapp</th>
                                    <th>Fb</th>
                                    <th>Insta</th>
                                    <th>Number</th>
                                    <th>Email</th>
                                    <th>Domain</th>
                                    <th colspan='2'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td contenteditable='true' data-field='name'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='fatherName'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='dp'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='whatsapp'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='fb'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='insta'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='number'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='email'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='domain'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td colspan='2'>
                                        <button class='btn btn-success btn-sm'
                                            onclick='managerRow(this,true,true)'>Add</button>
                                    </td>
                                </tr>
                                <?php
        $sql = "SELECT * FROM manager";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
				    <td>" . $row['id'] ."</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='name'>{$row['name']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='fatherName'>{$row['fatherName']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='dp'>{$row['dp']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='whatsapp'>{$row['whatsapp']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='fb'>{$row['fb']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='insta'>{$row['insta']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='number'>{$row['number']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='email'>{$row['email']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='domain'>{$row['domain']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='managerRow(this,true)' data-id='{$row['id']}'>Save</button>
                        </td>
                        <td>
                        <button class='btn btn-danger btn-sm' onclick='managerRow(this,false)' data-id='{$row['id']}'>Delete</button>
                        </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='10'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>

                    </div>
                </div>
 <!-- MANAGER SECTION END HERE------------------------------ -->

 <!-- TESTIMONIALS SECTION STARTS FROM HERE------------------------------ -->

                <div id="testimonials" class="content d-none">
                    <h2 style="text-align: center;">Testimonials</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box">Total:
                            <?php echo $testimonial_count ; ?>
                        </div>

                    </div>
                    <div class="table-responsive mt-5">
                        <table class="text-center table mt-7 overflow-auto">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Comment</th>
                                    <th>Dp</th>
                                    <th>Profession</th>
                                    <th colspan='2'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td contenteditable='true' data-field='name'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='comment'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='dp'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='profession'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td colspan='2'>
                                        <button class='btn btn-success btn-sm'
                                            onclick='testimonialRow(this,true,true)'>Add</button>
                                    </td>
                                </tr>
                                <?php
        $sql = "SELECT * FROM testimonials";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='name'>{$row['name']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='comment'>{$row['comment']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='dp'>{$row['dp']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='profession'>{$row['profession']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='testimonialRow(this,true)' data-id='{$row['id']}'>Save</button>
                        </td>
                        <td>
                        <button class='btn btn-danger btn-sm' onclick='testimonialRow(this,false)' data-id='{$row['id']}'>Delete</button>
                        </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>

                    </div>
                </div>
 <!-- TESTIMONIALS SECTION END HERE------------------------------ -->

 <!-- PACKAGES SECTION START FROM HERE------------------------------ -->
                <div id="packages" class="content d-none">
                    <h2 style="text-align: center;">Tour Packages</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box">Total:
                            <?php echo $tourpackage_count; ?>
                        </div>

                    </div>
                    <div class="table-responsive mt-5">
                        <table class="text-center table mt-7">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Pic</th>
                                    <th>Location</th>
                                    <th>About</th>
                                    <th>Stars</th>
                                    <th>People</th>
                                    <th colspan='2'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <!-- TO ADD NEW FIELD -->
                                    <td></td>
                                    <td contenteditable='true' data-field='pic'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='location'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='about'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='stars'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td contenteditable='true' data-field='people'><i class='fas fa-edit pl-3'
                                            aria-hidden='true'></i></td>
                                    <td colspan='2'>
                                        <button class='btn btn-success btn-sm'
                                            onclick='tourPackageRow(this,true,true)'>Add</button>
                                    </td>
                                </tr>
                                <?php
        $sql = "SELECT * FROM tourpackages";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='pic'>{$row['pic']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='location'>{$row['location']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='about'>{$row['about']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='stars'>{$row['stars']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='people'>{$row['people']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='tourPackageRow(this,true)' data-id='{$row['id']}'>Save</button>
                        </td>
                        <td>
                        <button class='btn btn-danger btn-sm' onclick='tourPackageRow(this,false)' data-id='{$row['id']}'>Delete</button>
                        </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>


                    </div>
                </div>
 <!-- PACKAGES SECTION ENDS HERE------------------------------ -->

 <!-- QUERIES SECTION START FROM HERE------------------------------ -->
                <div id="queries" class="content d-none">
                    <h2 style="text-align: center;">Queries</h2>
                    <div class="d-flex justify-content-around align-items-center">
                        <div class="box">Total:
                            <?php echo $query_count;?>
                        </div>
                    </div>

                    <div class="table-responsive mt-5">
                        <table class="text-center table mt-7">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Date</th>
                                    <th colspan="2">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
        $sql = "SELECT * FROM queries";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='name'>{$row['name']}<i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='email'>{$row['email']}<i class='fas fa-edit pl-3' aria-hidden='true'></i><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='subject'>{$row['subject']}<i class='fas fa-edit pl-3' aria-hidden='true'></i><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='message'>{$row['message']}<i class='fas fa-edit pl-3' aria-hidden='true'></i><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td contenteditable='true' data-id='{$row['id']}' data-field='message'>{$row['date']}<i class='fas fa-edit pl-3' aria-hidden='true'></i><i class='fas fa-edit pl-3' aria-hidden='true'></i></td>
                    <td>
                        <button class='btn btn-success btn-sm mb-1' onclick='queryRow(this,true)' data-id='{$row['id']}'>Save</button>
                        </td>
                        <td>
                        <button class='btn btn-danger btn-sm' onclick='queryRow(this,false)' data-id='{$row['id']}'>Delete</button>
                        </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No records found</td></tr>";
        }
        ?>
                            </tbody>
                        </table>


                    </div>
                </div>
 <!-- QUERIES SECTION ENDS HERE------------------------------ -->

            </main>
        </div>
    </div>
<!-- INCLUDES -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="../js/admin.js"></script>

</body>

</html>