<?php 
include_once '../connection.php';
include_once '../fechData.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['goToAdminPanel'])) {
	$username = htmlspecialchars(strip_tags(trim($_POST['Username'])));
	$password = htmlspecialchars(strip_tags(trim($_POST['password'])));

	// Query to check if the credentials are correct
	$query = "SELECT * FROM admin WHERE username = ? AND password = ?";
	if ($stmt = $conn->prepare($query)) {
		$stmt->bind_param("ss", $username, $password);
		$stmt->execute();
		$result = $stmt->get_result();
		
		if ($result->num_rows == 1) {
			$_SESSION['loggedin'] = true;
			header("Location: index.php"); // redirect to admin panel
			exit(); // Stop further execution after redirect
		} else {
			$error_message = "Wrong credentials";
		}
		$stmt->close();
	}
	$conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin Login</title>
	<link rel="stylesheet" href="../css/login.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
	<link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
	<link href="../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
</head>
<body>
	<div id="formDiv" class="container">
		<div class="row">
		  <div class="col-md-6 offset-md-3">
			<h2 class="text-center text-dark mt-5">Login</h2>
			<div class="card my-5">
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="card-body cardbody-color p-lg-5">
				   <div class="text-center">
						<img loading='lazy' src="../<?php echo isset($_SESSION['managerDp']) ? 'img/' . $_SESSION['managerDp'] : 'https://cdn-icons-png.flaticon.com/512/4042/4042356.png'; ?>" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3" width="200px" alt="profile">
					</div>
					<?php if (isset($error_message)): ?>
						<p style="color:red; text-align:center;"><b><?php echo $error_message; ?></b></p>
					<?php endif; ?>
					<div class="mb-3">
						<i class="fa fa-user"></i>
						<input type="text" class="form-control pl-4" name="Username" aria-describedby="emailHelp" placeholder="User Name" required>
					</div>
					<div class="mb-3">
						<i class="fa fa-key"></i>
						<input type="password" class="form-control pl-4" name="password" placeholder="password" required>
					</div>
					<div class="text-center"><button type="submit" name="goToAdminPanel">Go to admin panel</button></div>
				</form>
			</div>
		  </div>
		</div>
	</div>
</body>
</html>
