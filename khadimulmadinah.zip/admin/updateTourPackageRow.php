<?php
include_once '../connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];

    if ($action === 'ADD') {
        $pic = $_POST['pic'];
        $location = $_POST['location'];
        $about = $_POST['about'];
        $stars = $_POST['stars'];
        $people = $_POST['people'];

        $sql = "INSERT INTO tourpackages (pic, location, about, stars, people) VALUES ('$pic', '$location', '$about', '$stars', '$people')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Record added successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error adding record: " . $conn->error]);
        }
    } elseif ($action === 'UPDATE') {
        $id = $_POST['id'];
        $pic = $_POST['pic'];
        $location = $_POST['location'];
        $about = $_POST['about'];
        $stars = $_POST['stars'];
        $people = $_POST['people'];

        $sql = "UPDATE tourpackages SET pic='$pic', location='$location', about='$about', stars='$stars', people='$people' WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Updated successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error updating record: " . $conn->error]);
        }
    } elseif ($action === 'DELETE') {
        $id = $_POST['id'];
        $sql = "DELETE FROM tourpackages WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Record deleted successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error deleting record: " . $conn->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid action"]);
    }
}
?>
