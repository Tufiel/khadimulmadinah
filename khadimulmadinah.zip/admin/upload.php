<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $target_dir = "../img/";
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $endName = basename($_POST['endName']);
    $message = "";

    // Validate the file type
    if (in_array($imageFileType, ["jpg", "jpeg", "png"])) {
        $target_file = $target_dir . $endName . '.' . $imageFileType;

        // Check if the file already exists and remove it
        if (file_exists($target_file)) {
            if (!unlink($target_file)) {
                $message = "Sorry, there was an error deleting the existing file";
                header("Location: admin.php?message=" . urlencode($message));
                exit();
            }
        }

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $message = "The file " . htmlspecialchars(basename($_FILES["image"]["name"])) . " has been uploaded as " . htmlspecialchars($endName) . '.' . $imageFileType;
        } else {
            $message = "Sorry, there was an error uploading your file";
        }
    } else {
        $message = "Sorry, only JPG, JPEG, and PNG files are allowed";
    }

    // Redirect back to the form with a message
    header("Location: index.php?message=" . urlencode($message));
    exit();
} else {
    echo "<script>printMsg('Invalid request method','',false);</script>";
}
?>
