<?php



if ($_SERVER["REQUEST_METHOD"] == "POST") {

    
    if (isset($_POST['bookBtn'])) {
        $name = htmlspecialchars($_POST['name']);
        $number = htmlspecialchars($_POST['number']);
        $email = htmlspecialchars($_POST['email']);
        $destination = htmlspecialchars($_POST['destination']);
        date_default_timezone_set('Asia/Kolkata');
        $orderDate = date('d/m/Y h:i A');

        $travelDateInput = empty($_POST['travelDate'])?date('d/m/Y h:i A'):htmlspecialchars($_POST['travelDate']);
        $travelDateObj = DateTime::createFromFormat('Y-m-d', $travelDateInput);
        $travelDate = $travelDateObj->format('d/m/Y');
       

        // Prepare the SQL statement with placeholders
        $sql = "INSERT INTO `bookings`( `name`, `number`, `email`, `destination`, `traveldate`, `orderdate`) VALUES ('$name','$number','$email','$destination','$travelDate','$orderDate')";

            // Execute the statement
            if (mysqli_query($conn, $sql)) 
            echo '<script>msg(`Hello ' . htmlspecialchars($name) . ', our team will reach you shortly.`,5000);</script>';
            else 
                echo '<script>msg("Oops, something went wrong <br> Please contact the developer", 5000);</script>';
             
}

if (isset($_POST['subscribe'])) {
	$email = htmlspecialchars($_POST['email']);
	// Prepare the SQL statement with placeholders
    $subscribeDate = date('d/m/Y h:i A');
	$sql = "INSERT INTO subscribers ( `email`, `subscribeDate`) VALUES ('$email','$subscribeDate')";
	// Execute the statement
	if (mysqli_query($conn, $sql)) 
		echo '<script>msg(" ' . $email . ' subscribed successfully", 5000);</script>';
	 else 
		echo '<script>msg("Oops, something went wrong <br> Please contact the developer", 5000);</script>';
	 
}

if (isset($_POST['queryBtn'])) {
	$name = htmlspecialchars($_POST['name']);
    $subject = htmlspecialchars($_POST['subject']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
    date_default_timezone_set('Asia/Kolkata');
    $currentDate = date('d/m/Y h:i A');
	// Prepare the SQL statement with placeholders
    $sql = "INSERT INTO queries ( `name`, `email`, `subject`, `message`, `date`) VALUES ('$name','$email','$subject','$message','$currentDate')";

    // Execute the statement
    if (mysqli_query($conn, $sql)) 
        echo '<script>msg("Hello ' . htmlspecialchars($name) . ', our team will try to solve your query ASAP", 5000);</script>';
     else 
        echo '<script>msg("Oops, something went wrong <br> Please contact the developer", 5000);</script>';
     
}

// Close the statement
mysqli_close($conn); 

}
?>