-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 11, 2024 at 08:48 AM
-- Server version: 8.0.36-cll-lve
-- PHP Version: 8.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khadimul_madinah`
--
CREATE DATABASE IF NOT EXISTS `khadimul_madinah` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `khadimul_madinah`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int NOT NULL,
  `firstImage` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `mainHeading` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `firstParagraph` text COLLATE utf8mb4_general_ci,
  `secondParagraph` text COLLATE utf8mb4_general_ci,
  `firstSubheading` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `secondImage` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `thirdParagraph` text COLLATE utf8mb4_general_ci,
  `secondSubheading` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `thirdImage` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fourthParagraph` text COLLATE utf8mb4_general_ci,
  `publishDate` date DEFAULT NULL,
  `admin` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `heading` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `firstImage`, `mainHeading`, `firstParagraph`, `secondParagraph`, `firstSubheading`, `secondImage`, `thirdParagraph`, `secondSubheading`, `thirdImage`, `fourthParagraph`, `publishDate`, `admin`, `heading`) VALUES
(1, 'blog-1a.jpg', 'Our Journey of Spiritual Enlightenment: Completing Umrah', 'Embarking on the sacred journey of Umrah was a deeply transformative experience for us. As we set foot in the holy cities of Mecca and Medina, we were enveloped in a sense of peace and reverence that words can scarcely capture. The rituals of Umrah—performing Tawaf around the Kaaba, walking between Safa and Marwah, and reflecting in the serene environment of the holy mosques—provided us with a profound connection to our faith and heritage. Each step of this pilgrimage was a reminder of the timeless traditions and the spiritual significance of our devotion. We invite you to join us as we recount the moments of inspiration, challenges, and the immense blessings we received during our Umrah journey', 'Here’s a suggested second paragraph for your blog post: --- As we delved deeper into the rituals of Umrah, we found ourselves reflecting on the rich history and profound significance behind each practice. The act of Tawaf, circling the Kaaba in a state of humility and reverence, was particularly moving. Every step felt like a step closer to spiritual renewal, while the ancient stones of the Kaaba seemed to echo centuries of devotion. Walking between Safa and Marwah, retracing the footsteps of Hagar, brought a tangible connection to the enduring legacy of faith. These moments of worship, combined with the tranquil prayers offered in the Masjid al-Haram and Masjid an-Nabawi, helped us gain a deeper appreciation for the blessings and guidance we have in our lives. The experience of Umrah not only strengthened our faith but also enriched our understanding of the beautiful traditions of Islam. ---', 'Key Moments of Reflection and Worship During Umrah', 'blog-1b.jpg', 'Throughout our Umrah pilgrimage, we encountered moments of profound inspiration that left a lasting impact on our hearts. The serenity of the holy mosques offered a space for deep reflection and prayer, allowing us to connect more intimately with our Creator. We were moved by the sense of unity and brotherhood with fellow pilgrims from around the world, each person seeking spiritual growth and renewal. The challenges we faced during the journey—whether enduring the crowds or managing the physical demands of the pilgrimage—only served to deepen our gratitude and appreciation for the blessings of this sacred journey. Our time in Mecca and Medina was a reminder of the boundless mercy and grace of Allah, and we returned with a renewed sense of purpose and a deeper commitment to our faith', 'Personal Reflections and Lessons Learned from Umrah', 'blog-1c.jpg', 'The culmination of our Umrah journey was marked by a profound sense of fulfillment and peace. As we concluded our pilgrimage, we took time to reflect on the lessons learned and the spiritual growth experienced throughout the process. The pilgrimage not only allowed us to reconnect with our faith but also to appreciate the broader significance of our rituals and traditions. We left with a renewed commitment to embody the values of compassion, humility, and devotion in our daily lives. The memories of our time in the holy cities will forever be cherished, and the spiritual insights gained will continue to inspire and guide us. We are deeply grateful for the opportunity to have undertaken this sacred journey and are eager to share our experiences with others who may be contemplating their own pilgrimage', '2024-08-04', 'Bilal Ahmad Shah', 'Moments of Inspiration and Unity During Umrah');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `destination` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `traveldate` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `orderdate` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `name`, `number`, `email`, `destination`, `traveldate`, `orderdate`) VALUES
(1, 'Zahid', '7007805135', 'tufielgulzar20@gmail.com', 'Delhi', '24/08/2024', '08/08/2024 04:06 PM'),
(2, 'khushboo ', '67876787', 'khushboo112@gmail.com', 'germany', '08/10/2024', '08/08/2024 04:43 PM'),
(3, 'Tufiel Gulzar', '7007805135', 'tufielgulzar20@gmail.com', 'Delhi', '30/08/2024', '09/08/2024 06:55 PM'),
(4, 'Shadab Ali', '9821689378', 'shad46243@gmail.com', 'Testing', '11/08/2024', '11/08/2024 05:11 PM');

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `id` int NOT NULL,
  `pic` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `cities` varchar(50) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `destinations`
--

INSERT INTO `destinations` (`id`, `pic`, `name`, `cities`) VALUES
(2, 'india.jpg', 'India', '500'),
(3, 'china.jpg', 'China', '400'),
(4, 'brazil.jpg', 'Brazil', '200'),
(5, 'russia.jpg', 'Russia', '150'),
(6, 'australia.jpg', 'Australia', '100'),
(7, 'canada.jpg', 'Canada', '120'),
(8, 'france.jpg', 'France', '250'),
(9, 'germany.jpg', 'Germany', '230'),
(10, 'uk.jpg', 'United Kingdom', '150'),
(11, 'pakistan.jpg', 'Pakistan', '150'),
(12, 'uae.jpg', 'UAE', '30'),
(13, 'kuwait.jpg', 'Kuwait', '20'),
(14, 'qatar.jpg', 'Qatar', '20'),
(15, 'palestine.jpg', 'Palestine', '20'),
(16, 'us.jpg', 'United States', '300');

-- --------------------------------------------------------

--
-- Table structure for table `guides`
--

CREATE TABLE `guides` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `designation` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `dp` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'user',
  `whatsapp` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `fb` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guides`
--

INSERT INTO `guides` (`id`, `name`, `designation`, `dp`, `whatsapp`, `fb`) VALUES
(1, 'Tufail Gulzar', 'web designer and developer', 'tufail.jpg', 'https://wa.link/30onx2', 'https://www.facebook.com/TufailRather01');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `fatherName` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `dp` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'user',
  `whatsapp` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `fb` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `insta` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `domain` varchar(50) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `name`, `fatherName`, `dp`, `whatsapp`, `fb`, `insta`, `number`, `email`, `domain`) VALUES
(1, 'Bilal Ahmad Shah', 'Masood Ahmad Shah', 'managerDp.jpg', 'https://wa.link/c13olb', 'https://www.facebook.com/profile.php?id=61563626227616&mibextid=ZbWKwL', '#', '7006822587', 'BilalAhmadShah@khadimulmadinah.com', 'kahdimulmadinah.com');

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `id` int NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `subject` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `message` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `date` varchar(50) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`id`, `name`, `email`, `subject`, `message`, `date`) VALUES
(7, 'Tufiel Gulzar', 'tufielgulzar20@gmail.com', 'Testing', 'cpanel sdlkvnsdkfvbjn', '09/08/2024 04:05 PM'),
(8, 'Tufiel Gulzar', 'tufielgulzar20@gmail.com', 'online', 'online msg', '09/08/2024 06:56 PM');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `subscribeDate` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `subscribeDate`) VALUES
(1, 'letuscodefirst@gmail', '03/08/2024 02:54 PM'),
(4, 'tufielgulzar20@gmail', '08/08/2024 12:46 PM'),
(5, 'Tufail123@online', '09/08/2024 01:26 PM');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `comment` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `dp` varchar(500) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'user',
  `profession` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `comment`, `dp`, `profession`) VALUES
(1, 'Tufail Gulzar', 'Exceptional service and seamless travel planning made our trip unforgettable! Highly recommend for anyone looking to explore new destinations with ease and joy', 'tufail.jpg', 'Student'),
(2, 'Zahid Gulzar', 'Outstanding experience with this travel agency! Their expertise and personalized attention made our journey truly remarkable', 'zahid.jpg', 'Student'),
(3, 'Bilal Rather', 'Fantastic travel agency that goes above and beyond to create unforgettable adventures! Their attention to detail made our trip smooth and enjoyable.', 'user.jpg', 'Teacher'),
(4, 'Irfan Bhat', 'Highly impressed with the exceptional service and thoughtful planning! This travel agency made every moment of our trip special and stress-free', 'user.jpg', 'Driver');

-- --------------------------------------------------------

--
-- Table structure for table `tourpackages`
--

CREATE TABLE `tourpackages` (
  `id` int NOT NULL,
  `pic` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `about` varchar(300) COLLATE utf8mb4_general_ci NOT NULL,
  `stars` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `people` varchar(10) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tourpackages`
--

INSERT INTO `tourpackages` (`id`, `pic`, `location`, `about`, `stars`, `people`) VALUES
(1, 'tajmahal.jpg', 'Agra', 'Experience the timeless beauty and eternal love story of the Taj Mahal', '4.6', '212'),
(2, 'jamamasjid.jpg', 'Delhi', 'Experience the grandeur of Mughal architecture at Jama Masjid', '4.2', '170'),
(3, 'qatar.jpg', 'Qatar', 'Experience the timeless beauty of Qatar', '4.1', '457');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guides`
--
ALTER TABLE `guides`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `queries`
--
ALTER TABLE `queries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tourpackages`
--
ALTER TABLE `tourpackages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `guides`
--
ALTER TABLE `guides`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `queries`
--
ALTER TABLE `queries`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tourpackages`
--
ALTER TABLE `tourpackages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
