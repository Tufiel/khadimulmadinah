<?php
// Start the session
session_start();
include_once 'connection.php';
// Define the query to select the first row
$query = "SELECT * FROM manager LIMIT 1";

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query was successful and if any rows were returned
if ($result && mysqli_num_rows($result) > 0) {
    // Fetch the first row as an associative array
    $row = mysqli_fetch_assoc($result);
    
    // Store the data in session variables
    $_SESSION['managerName'] = $row['name'];
    $_SESSION['managerFather'] = $row['fatherName'];
    $_SESSION['managerDp'] = $row['dp'];
	$_SESSION['managerWhatsapp'] = $row['whatsapp'];
    $_SESSION['managerFb'] = $row['fb'];
	$_SESSION['managerInsta'] = $row['insta'];
	$_SESSION['managerNumber'] = $row['number'];
	$_SESSION['managerEmail'] = $row['email'];
	$_SESSION['domain'] = $row['domain'];

    
} else {
    $_SESSION['managerName'] = "Please update";
    $_SESSION['managerFather'] = "Please Update";
    $_SESSION['managerDp'] = "#";
	$_SESSION['whatsapp'] = "#";
    $_SESSION['managerFb'] = "#";
	$_SESSION['managerInsta'] = '#';
	$_SESSION['managerNumber'] = '#';
	$_SESSION['managerEmail'] = "#";
	$_SESSION['domain'] = "khadimulmadinah.com";

}

// Free result set
mysqli_free_result($result);

?>
